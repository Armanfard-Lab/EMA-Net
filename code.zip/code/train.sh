#!/bin/sh

python main.py --storage_root path/to/store/outputs --model_file configs/nyu/hrnet18/m_emanet.yml --cuda 0 --seed 0 --augmentation True
